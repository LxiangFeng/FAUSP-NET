from ultralytics import YOLO

def train_custom_yolov8(model_config_path, pretrained_weights_path, data_path, epochs, img_size, device, batch_size, workers):
    """
    Train a customized YOLOv8 model using pretrained weights for transfer learning.

    Parameters:
    - model_config_path: Path to the custom YOLOv8 model configuration file (.yaml)
    - pretrained_weights_path: Path to the pretrained weights file (.pt)
    - data_path: Path to the dataset configuration file (.yaml)
    - epochs: Number of training epochs
    - img_size: Input image size
    - device: Device ID for training (e.g., GPU ID)
    - batch_size: Batch size for training
    - workers: Number of worker threads for data loading
    - amp: Use automatic mixed precision (True/False)
    """

    # Initialize the model from the custom YAML file
    model = YOLO(model_config_path)

    # Load pretrained weights (Ultralytics YOLO automatically handles mismatch)
    model.load(pretrained_weights_path)

    # Train the model with the custom dataset
    model.train(
        data=data_path,
        epochs=epochs,
        imgsz=img_size,
        device=device,
        batch=batch_size,
        workers=workers
    )

if __name__ == "__main__":
    # Specify the paths
    model_config_path = r'/data_disk/lyp/fubu/yolov8/datasets1/yolov8.yaml'  # Custom model configuration
    pretrained_weights_path = r'/data_disk/lyp/fubu/yolov8/yolov8n.pt'  # Pretrained weights
    data_path = r'/data_disk/lyp/fubu/yolov8/datasets1/data.yaml'  # Dataset configuration
    epochs = 200
    img_size = 640
    device = '3'  # Assuming the first GPU; use 'cpu' for CPU training
    batch_size = 32
    workers = 8

    # Start the training process with transfer learning
    train_custom_yolov8(model_config_path, pretrained_weights_path, data_path, epochs, img_size, device, batch_size, workers)
